#!/usr/bin/env python3
"""Extract UI icons and reference crops from Minecraft Launcher screenshots."""
import numpy as np
from PIL import Image
from collections import Counter
import os

OUT = '/tmp/mc-assets/crops'
os.makedirs(OUT, exist_ok=True)

S1 = '/home/z/my-project/upload/pasted_image_1794446110114.png'  # play page
S2 = '/home/z/my-project/upload/pasted_image_1794446155280.png'  # dropdown open

img1 = Image.open(S1).convert('RGB')
arr1 = np.array(img1).astype(int)
img2 = Image.open(S2).convert('RGB')
arr2 = np.array(img2).astype(int)
H, W = arr1.shape[:2]
print('screenshot size', W, H)

# ---------- 1) Sidebar segments via divider detection ----------
SB_W = 268
sb = arr1[:, :SB_W]
rowstd = sb.std(axis=(1, 2))
sm = np.convolve(rowstd, np.ones(3) / 3, mode='same')
is_div = sm < 7
segs = []
y = 0
while y < H:
    if not is_div[y]:
        y0 = y
        while y < H and not is_div[y]:
            y += 1
        if y - y0 >= 22:
            segs.append((y0, y))
    else:
        y += 1
print('segments:', segs)


def bg_of(region):
    flat = (region // 4 * 4).reshape(-1, 3)
    cnt = Counter(map(tuple, flat.tolist()))
    return np.array(cnt.most_common(1)[0][0]) + 2


def extract_icon(a, y0, y1, x0=0, x1=120, thresh=28):
    region = a[y0:y1, x0:x1]
    bg = bg_of(region)
    diff = np.abs(region - bg).max(axis=2)
    mask = diff > thresh
    if mask.sum() < 60:
        return None
    ys, xs = np.where(mask)
    return (x0 + xs.min(), y0 + ys.min(), x0 + xs.max(), y0 + ys.max()), bg


for i, (y0, y1) in enumerate(segs):
    res = extract_icon(arr1, y0, y1)
    if res is None:
        print(f'seg {i} y{y0}-{y1}: no icon')
        continue
    (x0, iy0, x1, iy1), bg = res
    px0, py0, px1, py1 = max(0, x0 - 2), max(0, iy0 - 2), min(W, x1 + 3), min(H, iy1 + 3)
    crop = img1.crop((px0, py0, px1, py1))
    crop.save(f'{OUT}/side_{i:02d}_y{y0}-{y1}.png')
    print(f'seg {i} y{y0}-{y1}: icon bbox x{x0}-{x1} y{iy0}-{iy1} size {x1-x0}x{iy1-iy0} bg{bg.tolist()}')

# ---------- 2) Version selector grass icon (screenshot 2) ----------
region = arr2[770:900, 265:750]
r, g, b = region[:, :, 0], region[:, :, 1], region[:, :, 2]
green = (g > r + 15) & (g > b + 15) & (g > 70)
ys, xs = np.where(green)
if len(ys) > 100:
    gy0, gy1, gx0, gx1 = ys.min(), ys.max(), xs.min(), xs.max()
    print('grass green bbox in region:', gx0, gy0, gx1, gy1, 'counts', len(ys))
    reg = region[gy0:gy0 + 130, max(0, gx0 - 10):gx1 + 10]
    bg = bg_of(reg)
    diff = np.abs(reg - bg).max(axis=2)
    mask = diff > 25
    yy, xx = np.where(mask)
    by0, by1, bx0, bx1 = yy.min(), yy.max(), xx.min(), xx.max()
    ox = 265 + max(0, gx0 - 10); oy = 770 + gy0
    x0 = ox + bx0; x1 = ox + bx1
    y0 = oy + by0; y1 = oy + by1
    print('full block bbox:', x0, y0, x1, y1)
    img2.crop((x0 - 2, y0 - 2, x1 + 3, y1 + 3)).save(f'{OUT}/grass_selector.png')
    img2.crop((265, 770, 760, 900)).save(f'{OUT}/ref_selector_box.png')
else:
    print('no grass found in selector region, count=', len(ys))

img2.crop((265, 860, 760, 1059)).save(f'{OUT}/ref_dropdown.png')

# ---------- 3) PLAY button (green block detection, screenshot 1) ----------
region = arr1[700:920, 700:1300]
r, g, b = region[:, :, 0], region[:, :, 1], region[:, :, 2]
green = (g > r + 25) & (g > b + 25) & (g > 80)
ys, xs = np.where(green)
if len(ys) > 500:
    py0, py1, px0, px1 = ys.min(), ys.max(), xs.min(), xs.max()
    print('play green bbox:', px0 + 700, py0 + 700, px1 + 700, py1 + 700)
    img1.crop((700 + px0, 700 + py0, 700 + px1 + 1, 700 + py1 + 1)).save(f'{OUT}/ref_play_btn.png')

# ---------- 4) font-zoom reference crops (screenshot 1) ----------
zooms = {
    'font_tabs': (280, 20, 1010, 112),
    'font_sidebar_label': (88, 180, 268, 280),
    'font_promo': (1330, 95, 1909, 285),
    'font_giftcard': (1390, 620, 1909, 800),
    'ref_banner_logo': (700, 60, 1400, 300),
}
for name, (x0, y0, x1, y1) in zooms.items():
    c = img1.crop((x0, y0, x1, y1))
    if name.startswith('font_'):
        c = c.resize(((x1 - x0) * 3, (y1 - y0) * 3), Image.NEAREST)
    c.save(f'{OUT}/{name}.png')

# ---------- 5) news cards (screenshot 1, bottom row) ----------
row = arr1[940:1060, 280:1795]
bg = bg_of(row)
diff = np.abs(row - bg).max(axis=2)
colmask = (diff > 30).mean(axis=0) > 0.25
runs = []
x = 0
while x < len(colmask):
    if colmask[x]:
        x0 = x
        while x < len(colmask) and colmask[x]:
            x += 1
        if x - x0 > 200:
            runs.append((280 + x0, 280 + x))
    else:
        x += 1
print('card column runs:', runs)
for i, (x0, x1) in enumerate(runs[:4]):
    img1.crop((x0, 915, x1, 1071)).save(f'{OUT}/card_{i}.png')

print('done')
