#!/usr/bin/env python3
"""Refined icon extraction: icon-only crops via icon/text gap detection."""
import numpy as np
from PIL import Image
from collections import Counter
import os

OUT = '/tmp/mc-assets/crops'
os.makedirs(OUT, exist_ok=True)

S1 = '/home/z/my-project/upload/pasted_image_1794446110114.png'
S2 = '/home/z/my-project/upload/pasted_image_1794446155280.png'
img1 = Image.open(S1).convert('RGB')
arr1 = np.array(img1).astype(int)
img2 = Image.open(S2).convert('RGB')
arr2 = np.array(img2).astype(int)
H, W = arr1.shape[:2]


def bg_of(region):
    flat = (region // 4 * 4).reshape(-1, 3)
    cnt = Counter(map(tuple, flat.tolist()))
    return np.array(cnt.most_common(1)[0][0]) + 2


def icon_only(a, y0, y1, x0=10, x1=140, thresh=26):
    """Extract icon bounding box using column-gap between icon and label text."""
    region = a[y0:y1, x0:x1]
    bg = bg_of(region)
    diff = np.abs(region - bg).max(axis=2)
    mask = diff > thresh
    if mask.sum() < 40:
        return None
    # column density
    coldens = mask.mean(axis=0)
    cols = coldens > 0.06
    # find first run of content columns, then stop at a gap of >= 8 px
    xs = np.where(cols)[0]
    if len(xs) == 0:
        return None
    first = xs[0]
    last = first
    for x in range(first, len(cols)):
        if cols[x]:
            last = x
        elif x - last >= 9:
            break
    sub = mask[:, first:last + 1]
    ys2 = np.where(sub.any(axis=1))[0]
    return (x0 + first, y0 + ys2.min(), x0 + last, y0 + ys2.max())


rows = {
    'avatar':   (22, 74),
    'home':     (110, 180),
    'java':     (185, 278),
    'bedrock':  (285, 340),
    'dungeons2': (370, 425),
    'dungeons': (455, 510),
    'legends':  (538, 592),
    'whatsnew': (890, 942),
    'settings': (940, 995),
}
for name, (y0, y1) in rows.items():
    res = icon_only(arr1, y0, y1)
    if res is None:
        print(name, 'no icon found in', y0, y1)
        continue
    x0, iy0, x1, iy1 = res
    img1.crop((x0 - 2, iy0 - 2, x1 + 3, iy1 + 3)).save(f'{OUT}/icon_{name}.png')
    print(f'{name}: bbox x{x0}-{x1} y{iy0}-{iy1} size {x1-x0}x{iy1-iy0}')

# full sidebar label (java) for exact text read
img1.crop((80, 185, 268, 280)).resize((188 * 4, 95 * 4), Image.NEAREST).save(f'{OUT}/font_sidebar_full.png')
# bottom of sidebar: settings + version
img1.crop((0, 930, 268, 1071)).save(f'{OUT}/ref_sidebar_bottom.png')
# account header full
img1.crop((0, 0, 268, 110)).save(f'{OUT}/ref_account.png')

# ---------- grass block icon from version selector (screenshot 2) ----------
# selector box: scan x 265-760, y 770-900 for the box; icon is at left inside box.
# The box has a border ~ #6a6a6a; find box left edge, then icon = content within x boxleft+8 .. boxleft+70
region = arr2[765:905, 260:780]
bg = bg_of(region)
diff = np.abs(region - bg).max(axis=2)
mask = diff > 22
# the box border is a vertical line near x=260..270 area; find columns with high density
coldens = mask.mean(axis=0)
# print top density columns to locate box
topcols = np.argsort(coldens)[-12:]
print('high-density cols (offset 260):', sorted((int(c) + 260, round(float(coldens[c]), 2)) for c in topcols))

# Instead: crop generous area around icon: icon sits ~x 285-345 based on box at x~270
icon_area = arr2[780:895, 275:360]
bg2 = bg_of(icon_area)
d2 = np.abs(icon_area - bg2).max(axis=2)
m2 = d2 > 25
if m2.sum() > 100:
    ys, xs = np.where(m2)
    x0, x1, y0, y1 = 275 + xs.min(), 275 + xs.max(), 780 + ys.min(), 780 + ys.max()
    print('selector icon bbox:', x0, y0, x1, y1, 'size', x1 - x0, y1 - y0)
    img2.crop((x0 - 2, y0 - 2, x1 + 3, y1 + 3)).save(f'{OUT}/icon_grass.png')
else:
    print('selector icon not found, mask sum', m2.sum())

# dropdown entry icons: custom installation icon (paper bag) rows in screenshot 2
img2.crop((265, 860, 760, 1000)).save(f'{OUT}/ref_dropdown_top.png')
print('done')
