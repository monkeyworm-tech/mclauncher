#!/usr/bin/env python3
"""Fix broken icon crops (bedrock, settings), trim grass, and process all assets."""
import numpy as np
from PIL import Image
from collections import Counter
import os

OUT = '/tmp/mc-assets/crops'
S1 = '/home/z/my-project/upload/pasted_image_1794446110114.png'
S2 = '/home/z/my-project/upload/pasted_image_1794446155280.png'
img1 = Image.open(S1).convert('RGB')
arr1 = np.array(img1).astype(int)
img2 = Image.open(S2).convert('RGB')
arr2 = np.array(img2).astype(int)


def bg_of(region):
    flat = (region // 4 * 4).reshape(-1, 3)
    cnt = Counter(map(tuple, flat.tolist()))
    return np.array(cnt.most_common(1)[0][0]) + 2


def find_content(a, y0, y1, x0, x1, thresh=26, bg=None):
    region = a[y0:y1, x0:x1]
    if bg is None:
        bg = bg_of(region)
    diff = np.abs(region - bg).max(axis=2)
    mask = diff > thresh
    if mask.sum() < 30:
        return None
    ys, xs = np.where(mask)
    return (x0 + xs.min(), y0 + ys.min(), x0 + xs.max(), y0 + ys.max()), bg, mask


# --- settings icon: scan wider region below whatsnew
res = find_content(arr1, 940, 1040, 12, 90)
print('settings region content:', res[0] if res else None)
if res:
    (x0, y0, x1, y1), bg, mask = res
    img1.crop((x0 - 2, y0 - 2, x1 + 3, y1 + 3)).save(f'{OUT}/icon_settings.png')
    print('settings icon saved', x0, y0, x1, y1)

# --- bedrock icon: crop wider window
res = find_content(arr1, 280, 350, 10, 100)
print('bedrock region content:', res[0] if res else None)
if res:
    (x0, y0, x1, y1), bg, mask = res
    # limit to icon: content before the text gap (use column gap approach)
    coldens = mask.mean(axis=0)
    cols = coldens > 0.08
    xs = np.where(cols)[0]
    first, last = xs[0], xs[0]
    for x in range(first, len(cols)):
        if cols[x]:
            last = x
        elif x - last >= 8:
            break
    sub = mask[:, first:last + 1]
    ys2 = np.where(sub.any(axis=1))[0]
    bx0, by0, bx1, by1 = 10 + first, 280 + ys2.min(), 10 + last, 280 + ys2.max()
    img1.crop((bx0 - 2, by0 - 2, bx1 + 3, by1 + 3)).save(f'{OUT}/icon_bedrock.png')
    print('bedrock icon saved', bx0, by0, bx1, by1, 'size', bx1 - bx0, by1 - by0)

# --- grass: trim bottom sliver - find content excluding last rows
region = arr2[790:890, 278:355]
res = find_content(arr2, 790, 890, 278, 355)
if res:
    (x0, y0, x1, y1), bg, mask = res
    # take only the largest vertical run: grass block is a solid cluster; sliver at bottom separate
    rows = mask.any(axis=1)
    runs = []
    y = 0
    while y < len(rows):
        if rows[y]:
            y0r = y
            while y < len(rows) and rows[y]:
                y += 1
            runs.append((y0r, y))
        else:
            y += 1
    runs = [r for r in runs if r[1] - r[0] > 20]
    if runs:
        ry0, ry1 = runs[0]
        sub = mask[ry0:ry1]
        ys2, xs2 = np.where(sub)
        gx0, gy0, gx1, gy1 = 278 + xs2.min(), 790 + ry0 + ys2.min(), 278 + xs2.max(), 790 + ry0 + ys2.max()
        img2.crop((gx0 - 1, gy0 - 1, gx1 + 2, gy1 + 2)).save(f'{OUT}/icon_grass.png')
        print('grass saved', gx0, gy0, gx1, gy1, 'size', gx1 - gx0, gy1 - gy0)
print('done')
