#!/usr/bin/env python3
"""Process and install all launcher assets into the Next.js public folder."""
import os
import numpy as np
from PIL import Image

SRC = '/tmp/mc-assets'
CROPS = f'{SRC}/crops'
PUB = '/home/z/my-project/public'

for d in ['images/icons', 'images/cards', 'fonts']:
    os.makedirs(f'{PUB}/{d}', exist_ok=True)


def has_alpha(img):
    return img.mode in ('RGBA', 'LA', 'P') and (
        img.mode != 'P' or 'transparency' in img.info)


def trim_alpha(img, pad=0):
    """Trim transparent borders."""
    if not has_alpha(img):
        return img
    rgba = img.convert('RGBA')
    a = np.array(rgba)[:, :, 3]
    ys, xs = np.where(a > 8)
    if len(ys) == 0:
        return img
    x0, y0, x1, y1 = xs.min(), ys.min(), xs.max(), ys.max()
    return rgba.crop((max(0, x0 - pad), max(0, y0 - pad),
                      min(rgba.width, x1 + 1 + pad), min(rgba.height, y1 + 1 + pad)))


def save_upscaled(name, scale=3):
    p = f'{CROPS}/icon_{name}.png'
    if not os.path.exists(p):
        print('MISSING', p)
        return
    img = Image.open(p).convert('RGBA')
    img = img.resize((img.width * scale, img.height * scale), Image.NEAREST)
    img.save(f'{PUB}/images/icons/{name}.png')
    print(f'icon {name}: {img.size}')


# 1) banner + logo
banner = Image.open(f'{SRC}/banner.png').convert('RGB')
banner.save(f'{PUB}/images/banner.png', optimize=True)
logo = trim_alpha(Image.open(f'{SRC}/minecraft_logo.png'))
logo.save(f'{PUB}/images/logo.png')
print('banner', banner.size, 'logo', logo.size, 'alpha', has_alpha(logo))

# 2) block renders (furnace / crafting table) - trim transparent margins
for src, dst in [('furnace.png', 'furnace.png'), ('crafting_table.png', 'crafting-table.png')]:
    img = trim_alpha(Image.open(f'{SRC}/{src}'))
    img.save(f'{PUB}/images/{dst}')
    print(dst, img.size, 'alpha', has_alpha(img))

# 3) sidebar icons upscaled 3x (pixel art -> crisp)
for name in ['avatar', 'home', 'java', 'bedrock', 'dungeons2', 'dungeons',
             'legends', 'whatsnew', 'settings', 'grass']:
    save_upscaled(name)

# 4) news cards
for src, dst in [('card_left.png', 'news-1.png'), ('card_0.png', 'news-2.png'),
                 ('card_1.png', 'news-3.png')]:
    img = Image.open(f'{CROPS}/{src}').convert('RGB')
    img.save(f'{PUB}/images/cards/{dst}')
    print('card', dst, img.size)

# 5) favicon from grass block
g = Image.open(f'{PUB}/images/icons/java.png').convert('RGBA')
side = max(g.size)
g = g.crop((0, 0, side, side)).resize((64, 64), Image.NEAREST)
g.save(f'{PUB}/favicon.png')
print('favicon saved')

# 6) fonts
import shutil
for f in os.listdir(f'{SRC}/fonts'):
    shutil.copy(f'{SRC}/fonts/{f}', f'{PUB}/fonts/{f}')
print('fonts:', sorted(os.listdir(f'{PUB}/fonts')))
print('done')
