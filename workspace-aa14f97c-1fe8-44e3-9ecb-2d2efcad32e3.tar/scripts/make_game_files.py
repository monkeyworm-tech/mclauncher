#!/usr/bin/env python3
"""Generate placeholder game HTML files (26-3.html, 26-2.html, 20-6.html)."""
import os

GAMES = [
    ("26-3.html", "26.3", "Latest release"),
    ("26-2.html", "26.2", "release 26.2"),
    ("20-6.html", "1.20.6", "release 1.20.6"),
]

TEMPLATE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Minecraft {version}</title>
<style>
  @font-face {{
    font-family: 'Minecraft';
    src: url('/fonts/minecraft-idrees.otf') format('opentype');
  }}
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  html, body {{ height: 100%; }}
  body {{
    background: #171615;
    background-image:
      linear-gradient(rgba(23, 22, 21, 0.82), rgba(23, 22, 21, 0.82)),
      repeating-conic-gradient(#2c2a28 0% 25%, #211f1e 0% 50%);
    background-size: auto, 56px 56px;
    color: #e0e5e2;
    font-family: 'Minecraft', 'Courier New', monospace;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 34px;
    text-align: center;
    padding: 24px;
    user-select: none;
  }}
  img.logo {{
    width: min(430px, 78vw);
    image-rendering: auto;
    filter: drop-shadow(0 8px 18px rgba(0, 0, 0, 0.65));
  }}
  .version {{
    font-size: 17px;
    letter-spacing: 0.05em;
    text-shadow: 2px 2px 0 rgba(0, 0, 0, 0.55);
  }}
  .version small {{
    display: block;
    margin-top: 10px;
    font-size: 12px;
    color: #9a9a9a;
  }}
  .bar {{
    width: min(360px, 70vw);
    height: 14px;
    border: 2px solid #000;
    background: #262524;
    box-shadow: inset 0 2px 0 rgba(0, 0, 0, 0.5);
    overflow: hidden;
  }}
  .bar i {{
    display: block;
    height: 100%;
    width: 40%;
    background: linear-gradient(180deg, #57984a, #3f7630);
    animation: load 1.6s steps(24) infinite;
  }}
  @keyframes load {{
    0% {{ width: 4%; }}
    100% {{ width: 100%; }}
  }}
  .note {{
    position: fixed;
    bottom: 22px;
    left: 50%;
    transform: translateX(-50%);
    font-family: 'Noto Sans', Arial, sans-serif;
    font-size: 12px;
    color: #8c8987;
    max-width: 90vw;
  }}
</style>
</head>
<body>
  <img class="logo" src="/images/logo.png" alt="Minecraft: Java Edition">
  <div class="version">
    Minecraft {version} &mdash; {label}
    <small>Loading&hellip;</small>
  </div>
  <div class="bar" role="progressbar" aria-label="Loading"><i></i></div>
  <p class="note">This is a placeholder game screen. Replace the file <b>{file}</b> in the
  <b>public</b> folder with your own game file &mdash; the launcher will open it in this window.</p>
</body>
</html>
"""

PUB = "/home/z/my-project/public"
for file, version, label in GAMES:
    path = os.path.join(PUB, file)
    with open(path, "w", encoding="utf-8") as f:
        f.write(TEMPLATE.format(version=version, label=label, file=file))
    print("wrote", path)
