#!/usr/bin/env python3
"""Sample exact UI colors from launcher screenshots."""
import numpy as np
from PIL import Image

S1 = '/home/z/my-project/upload/pasted_image_1794446110114.png'
S2 = '/home/z/my-project/upload/pasted_image_1794446155280.png'
S3 = '/home/z/my-project/upload/pasted_image_1794446233209.png'
S4 = '/home/z/my-project/upload/pasted_image_1794446244588.png'

imgs = {n: np.array(Image.open(p).convert('RGB')).astype(int) for n, p in
        [('s1', S1), ('s2', S2), ('s3', S3), ('s4', S4)]}


def swatch(img, x0, y0, x1, y1, label, filter_dark=None, filter_green=None):
    a = imgs[img][y0:y1, x0:x1]
    if filter_dark is not None:
        m = a.max(axis=2) > filter_dark
        a = a[m] if m.sum() > 10 else a
    if filter_green is not None:
        r, g, b = a[:, 0], a[:, 1], a[:, 2]
        m = (g > r + 20) & (g > b + 20)
        a = a[m] if m.sum() > 10 else a
    c = a.reshape(-1, 3).mean(axis=0).round(0).astype(int)
    print(f'{img} {label:42s} #{c[0]:02x}{c[1]:02x}{c[2]:02x}  rgb{tuple(c)}  n={len(a)}')


print('=== SIDEBAR (s1) ===')
swatch('s1', 1, 4, 7, 270, 'selected row left bar', filter_dark=100)
swatch('s1', 60, 200, 90, 270, 'selected row bg')
swatch('s1', 60, 125, 90, 165, 'home row bg')
swatch('s1', 60, 295, 90, 328, 'bedrock row bg')
swatch('s1', 100, 185, 250, 195, 'divider home/java')
swatch('s1', 100, 700, 250, 850, 'sidebar bg empty area')
swatch('s1', 150, 30, 260, 90, 'account header bg')
swatch('s1', 100, 985, 250, 1015, 'settings row bg')
print('=== TABS / TOP (s1) ===')
swatch('s1', 290, 28, 520, 50, 'overline text', filter_dark=150)
swatch('s1', 295, 60, 345, 95, 'active tab text', filter_dark=150)
swatch('s1', 470, 60, 560, 95, 'inactive tab text', filter_dark=120)
swatch('s1', 300, 104, 340, 112, 'tab underline green', filter_green=1)
swatch('s1', 290, 0, 1900, 25, 'top bar bg')
print('=== PLAY AREA (s1) ===')
swatch('s1', 860, 770, 1240, 830, 'PLAY face', filter_green=1)
swatch('s1', 860, 747, 1240, 758, 'PLAY top highlight', filter_green=1)
swatch('s1', 860, 838, 1240, 853, 'PLAY bottom bevel', filter_green=1)
swatch('s1', 300, 905, 1700, 916, 'main bg below banner')
swatch('s1', 800, 905, 900, 915, 'cards row bg (gap)')
print('=== VERSION SELECTOR (s2, open) ===')
swatch('s2', 340, 800, 640, 870, 'selector interior')
swatch('s2', 271, 790, 273, 890, 'selector left border')
swatch('s2', 340, 890, 640, 950, 'dropdown open bg')
swatch('s2', 300, 895, 640, 950, 'dropdown selected row bg')
swatch('s2', 350, 800, 600, 830, 'Latest release text', filter_dark=150)
swatch('s2', 350, 838, 500, 860, '26.3 faded text', filter_dark=90)
print('=== PROMO / GIFT (s2) ===')
swatch('s2', 1370, 125, 1790, 260, 'promo box bg')
swatch('s2', 1370, 130, 1790, 255, 'promo text', filter_dark=150)
print('=== INSTALLATIONS PAGE (s3) ===')
# find search box: scan for green border rows
a = imgs['s3']
region = a[120:280, 280:800]
r, g, b = region[:, :, 0], region[:, :, 1], region[:, :, 2]
gm = (g > r + 25) & (g > b + 25) & (g > 70)
ys, xs = np.where(gm)
if len(ys):
    print('green pixels in filter region bbox y', 120 + ys.min(), 120 + ys.max(), 'x', 280 + xs.min(), 280 + xs.max())
swatch('s3', 300, 170, 700, 210, 'search interior')
# play buttons: green clusters in list area
region = a[300:1000, 1350:1750]
r, g, b = region[:, :, 0], region[:, :, 1], region[:, :, 2]
gm = (g > r + 25) & (g > b + 25) & (g > 70)
ys, xs = np.where(gm)
if len(ys):
    print('play btn green bbox y', 300 + ys.min(), 300 + ys.max(), 'x', 1350 + xs.min(), 1350 + xs.max())
swatch('s3', 0, 130, 260, 900, 'sidebar bg s3')
swatch('s3', 300, 300, 1700, 1000, 'list bg s3')
print('=== MODAL (s4) ===')
swatch('s4', 700, 500, 1200, 900, 'modal bg')
swatch('s4', 680, 270, 1230, 310, 'name input bg (focused)')
swatch('s4', 680, 272, 1228, 308, 'name input border green', filter_green=1)
swatch('s4', 900, 555, 1050, 575, 'game dir input text', filter_dark=90)
swatch('s4', 1660, 958, 1760, 992, 'cancel btn')
swatch('s4', 1775, 955, 1885, 995, 'install btn', filter_green=1)
