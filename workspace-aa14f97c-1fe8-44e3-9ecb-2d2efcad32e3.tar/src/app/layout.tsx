import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: "Minecraft Launcher",
  description:
    "Minecraft Launcher — play Minecraft: Java Edition, manage installations and launch any version.",
  icons: {
    icon: "/favicon.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased bg-[#171615] text-[#e0e5e2] overflow-hidden">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
