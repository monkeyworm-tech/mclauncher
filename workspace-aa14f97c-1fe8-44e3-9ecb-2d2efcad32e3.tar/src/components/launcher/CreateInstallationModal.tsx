"use client";

import { useEffect, useRef, useState } from "react";
import {
  ChevronDown,
  Download,
  ExternalLink,
  Monitor,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useLauncherStore } from "@/lib/store";
import {
  INSTALL_ICONS,
  VERSIONS,
  getVersion,
  launchInstallation,
  type InstallIcon,
  type Installation,
  type VersionId,
} from "@/lib/launcher";
import { useToast } from "@/hooks/use-toast";

function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <span className="mb-1.5 block text-[12px] font-bold uppercase tracking-[0.08em] text-[#f0f0f0]">
      {children}
    </span>
  );
}

const RES_PRESETS = ["Default (<auto>)", "854 × 480", "1280 × 720", "1920 × 1080"];

export function CreateInstallationModal() {
  const close = useLauncherStore((s) => s.closeCreateModal);
  const addInstallation = useLauncherStore((s) => s.addInstallation);
  const { toast } = useToast();

  const [name, setName] = useState("");
  const [versionId, setVersionId] = useState<VersionId>("latest-release");
  const [icon, setIcon] = useState<InstallIcon>("furnace");
  const [directory, setDirectory] = useState("");
  const [resW, setResW] = useState("");
  const [resH, setResH] = useState("");
  const [javaPath, setJavaPath] = useState("");
  const [jvmArgs, setJvmArgs] = useState("");
  const [launchAfter, setLaunchAfter] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);

  const [iconPickerOpen, setIconPickerOpen] = useState(false);
  const [versionOpen, setVersionOpen] = useState(false);
  const [resOpen, setResOpen] = useState(false);

  const nameRef = useRef<HTMLInputElement>(null);
  const iconRef = useRef<HTMLDivElement>(null);
  const versionRef = useRef<HTMLDivElement>(null);
  const resRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = setTimeout(() => nameRef.current?.focus(), 60);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node;
      if (
        !iconRef.current?.contains(t) &&
        !versionRef.current?.contains(t) &&
        !resRef.current?.contains(t)
      ) {
        setIconPickerOpen(false);
        setVersionOpen(false);
        setResOpen(false);
      }
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("mousedown", onDown);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onDown);
    };
  }, [close]);

  const selectedIcon = INSTALL_ICONS.find((i) => i.id === icon) ?? INSTALL_ICONS[0];
  const selectedVersion = getVersion(versionId);

  const install = () => {
    const inst: Installation = {
      id: `inst-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      name: name.trim() || "unnamed installation",
      versionId,
      icon,
      directory: directory.trim() || undefined,
      resolutionW: resW.trim() || undefined,
      resolutionH: resH.trim() || undefined,
      createdAt: Date.now(),
    };
    addInstallation(inst);
    close();
    toast({
      title: "Installation created",
      description: `“${inst.name}” (${selectedVersion.label}) was added to the play area.`,
    });
    if (launchAfter) {
      launchInstallation(inst);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Create new installation"
      className="fixed inset-0 z-[60] flex flex-col bg-[#20211d]"
    >
      {/* Header */}
      <div className="relative shrink-0 border-b border-[#333] px-6 py-5">
        <h2 className="text-center text-[20px] font-bold text-[#f0f0f0]">
          Create new installation
        </h2>
        <button
          type="button"
          onClick={close}
          aria-label="Close"
          className="absolute right-5 top-1/2 -translate-y-1/2 p-2 text-[#e0e0e0] transition-colors hover:bg-[#2a2827] hover:text-white"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Body */}
      <div className="mc-scroll flex-1 overflow-y-auto">
        <div className="mx-auto flex w-[460px] max-w-full flex-col gap-6 px-5 py-8">
          {/* Icon selector */}
          <div className="flex justify-center" ref={iconRef}>
            <div className="relative">
              <button
                type="button"
                aria-haspopup="menu"
                aria-expanded={iconPickerOpen}
                aria-label="Choose installation icon"
                onClick={() => setIconPickerOpen((o) => !o)}
                className="flex items-center gap-2 p-1 transition-colors hover:bg-[#2a2827]"
              >
                <img
                  src={selectedIcon.src}
                  alt={selectedIcon.label}
                  className="mc-pixel h-[52px] w-[52px] object-contain"
                  draggable={false}
                />
                <ChevronDown className="h-4 w-4 text-[#cccccc]" />
              </button>
              {iconPickerOpen && (
                <div
                  role="menu"
                  className="absolute left-1/2 top-[calc(100%+6px)] z-10 flex -translate-x-1/2 gap-1 border border-[#454340] bg-[#262524] p-2 shadow-[0_8px_20px_rgba(0,0,0,0.55)]"
                >
                  {INSTALL_ICONS.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      role="menuitem"
                      title={opt.label}
                      onClick={() => {
                        setIcon(opt.id);
                        setIconPickerOpen(false);
                      }}
                      className={cn(
                        "flex h-[56px] w-[56px] items-center justify-center p-1 transition-colors",
                        icon === opt.id
                          ? "bg-[#4a4846] ring-1 ring-inset ring-[#8a8886]"
                          : "hover:bg-[#312f2d]",
                      )}
                    >
                      <img
                        src={opt.src}
                        alt={opt.label}
                        className="mc-pixel h-[42px] w-[42px] object-contain"
                        draggable={false}
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* NAME */}
          <div>
            <label htmlFor="new-inst-name" className="block">
              <FieldLabel>Name</FieldLabel>
            </label>
            <input
              id="new-inst-name"
              ref={nameRef}
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="unnamed installation"
              className="h-[40px] w-full border-2 border-transparent bg-[#2a2827] px-3.5 text-[14px] text-[#f0f0f0] placeholder-[#9a9a9a] focus:border-[#4c8c39] focus:outline-none"
            />
          </div>

          {/* VERSION */}
          <div>
            <span className="block">
              <FieldLabel>Version</FieldLabel>
            </span>
            <div className="flex items-start gap-4">
              <div className="relative w-[330px] max-w-full" ref={versionRef}>
                <button
                  type="button"
                  aria-haspopup="listbox"
                  aria-expanded={versionOpen}
                  onClick={() => setVersionOpen((o) => !o)}
                  className={cn(
                    "flex h-[48px] w-full items-center justify-between gap-2 px-3.5 text-left text-[14px] transition-colors",
                    "bg-[#2a2827] text-[#f0f0f0]",
                    versionOpen
                      ? "border-2 border-[#4c8c39]"
                      : "border-2 border-[#4a4a4a] hover:border-[#5a5a5a]",
                  )}
                >
                  {selectedVersion.label}
                  <ChevronDown
                    className={cn(
                      "h-4 w-4 shrink-0 text-[#cccccc] transition-transform",
                      versionOpen && "rotate-180",
                    )}
                  />
                </button>
                {versionOpen && (
                  <div
                    role="listbox"
                    className="mc-scroll absolute left-0 right-0 top-[calc(100%+4px)] z-10 max-h-[220px] overflow-y-auto border-2 border-[#454340] bg-[#262524] py-1 shadow-[0_10px_24px_rgba(0,0,0,0.55)]"
                  >
                    {VERSIONS.map((v) => (
                      <button
                        key={v.id}
                        type="button"
                        role="option"
                        aria-selected={versionId === v.id}
                        onClick={() => {
                          setVersionId(v.id);
                          setVersionOpen(false);
                        }}
                        className={cn(
                          "flex w-full items-center justify-between px-3.5 py-2.5 text-left text-[14px] transition-colors",
                          versionId === v.id
                            ? "bg-[#4a4846] font-bold text-[#f0f0f0]"
                            : "text-[#c9c7c4] hover:bg-[#312f2d]",
                        )}
                      >
                        {v.label}
                        {versionId === v.id && (
                          <span className="text-[11px] font-normal text-[#9a9a9a]">
                            selected
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2 pt-3.5">
                <span className="text-[12px] font-bold uppercase tracking-[0.08em] text-[#f0f0f0]">
                  Server
                </span>
                <button
                  type="button"
                  aria-label="Download server jar"
                  title="Download server jar"
                  onClick={() =>
                    toast({
                      title: "Server download",
                      description: `Server files for ${selectedVersion.label} would download here.`,
                    })
                  }
                  className="p-1 text-[#c9c7c4] transition-colors hover:text-white"
                >
                  <Download className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  aria-label="Open server website"
                  title="Open server website"
                  onClick={() =>
                    toast({
                      title: "Server website",
                      description: "Opens the server download page in the desktop launcher.",
                    })
                  }
                  className="p-1 text-[#c9c7c4] transition-colors hover:text-white"
                >
                  <ExternalLink className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>

          {/* GAME DIRECTORY */}
          <div>
            <label htmlFor="new-inst-dir" className="block">
              <FieldLabel>Game directory</FieldLabel>
            </label>
            <div className="flex items-center gap-3">
              <input
                id="new-inst-dir"
                type="text"
                value={directory}
                onChange={(e) => setDirectory(e.target.value)}
                placeholder="<Use default directory>"
                className="h-[40px] min-w-0 flex-1 border-2 border-transparent bg-[#2a2827] px-3.5 text-[14px] text-[#f0f0f0] placeholder-[#9a9a9a] focus:border-[#4c8c39] focus:outline-none"
              />
              <button
                type="button"
                onClick={() =>
                  toast({
                    title: "Browse",
                    description: "Choose a folder in the desktop launcher.",
                  })
                }
                className="shrink-0 text-[13px] font-bold uppercase tracking-[0.06em] text-[#f0f0f0] transition-colors hover:text-white"
              >
                Browse
              </button>
            </div>
          </div>

          {/* RESOLUTION */}
          <div>
            <span className="block">
              <FieldLabel>Resolution</FieldLabel>
            </span>
            <div className="flex items-center gap-3">
              <div className="relative" ref={resRef}>
                <button
                  type="button"
                  aria-haspopup="menu"
                  aria-expanded={resOpen}
                  aria-label="Resolution presets"
                  onClick={() => setResOpen((o) => !o)}
                  className="flex items-center gap-1.5 px-1 py-2 text-[#c9c7c4] transition-colors hover:text-white"
                >
                  <Monitor className="h-[22px] w-[22px]" />
                  <ChevronDown className="h-4 w-4" />
                </button>
                {resOpen && (
                  <div
                    role="menu"
                    className="absolute left-0 top-[calc(100%+4px)] z-10 w-[160px] border border-[#454340] bg-[#262524] py-1 shadow-[0_8px_20px_rgba(0,0,0,0.55)]"
                  >
                    {RES_PRESETS.map((p) => (
                      <button
                        key={p}
                        type="button"
                        role="menuitem"
                        onClick={() => {
                          const m = p.match(/(\d+)\s*×\s*(\d+)/);
                          setResW(m ? m[1] : "");
                          setResH(m ? m[2] : "");
                          setResOpen(false);
                        }}
                        className="block w-full px-3 py-2 text-left text-[13px] text-[#c9c7c4] hover:bg-[#312f2d] hover:text-white"
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <input
                type="text"
                inputMode="numeric"
                value={resW}
                onChange={(e) =>
                  setResW(e.target.value.replace(/[^0-9]/g, "").slice(0, 5))
                }
                placeholder="<auto>"
                aria-label="Window width"
                className="h-[42px] w-[150px] border-2 border-transparent bg-[#2a2827] text-center text-[14px] text-[#f0f0f0] placeholder-[#9a9a9a] focus:border-[#4c8c39] focus:outline-none"
              />
              <span className="text-[16px] text-[#8a8a8a]">×</span>
              <input
                type="text"
                inputMode="numeric"
                value={resH}
                onChange={(e) =>
                  setResH(e.target.value.replace(/[^0-9]/g, "").slice(0, 5))
                }
                placeholder="<auto>"
                aria-label="Window height"
                className="h-[42px] w-[150px] border-2 border-transparent bg-[#2a2827] text-center text-[14px] text-[#f0f0f0] placeholder-[#9a9a9a] focus:border-[#4c8c39] focus:outline-none"
              />
            </div>
          </div>

          {/* MORE OPTIONS */}
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => setMoreOpen((o) => !o)}
              aria-expanded={moreOpen}
              className="flex items-center gap-1.5 text-[12px] font-bold uppercase tracking-[0.08em] text-[#f0f0f0] transition-colors hover:text-white"
            >
              More options
              <ChevronDown
                className={cn("h-4 w-4 transition-transform", moreOpen && "rotate-180")}
              />
            </button>
          </div>
          {moreOpen && (
            <div className="flex flex-col gap-6 border-l-2 border-[#3a3836] pl-5">
              <div>
                <label htmlFor="new-inst-java" className="block">
                  <FieldLabel>Java executable</FieldLabel>
                </label>
                <input
                  id="new-inst-java"
                  type="text"
                  value={javaPath}
                  onChange={(e) => setJavaPath(e.target.value)}
                  placeholder="<Use default Java executable>"
                  className="h-[40px] w-full border-2 border-transparent bg-[#2a2827] px-3.5 text-[14px] text-[#f0f0f0] placeholder-[#9a9a9a] focus:border-[#4c8c39] focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="new-inst-jvm" className="block">
                  <FieldLabel>JVM arguments</FieldLabel>
                </label>
                <input
                  id="new-inst-jvm"
                  type="text"
                  value={jvmArgs}
                  onChange={(e) => setJvmArgs(e.target.value)}
                  placeholder="<Use default JVM arguments>"
                  className="h-[40px] w-full border-2 border-transparent bg-[#2a2827] px-3.5 text-[14px] text-[#f0f0f0] placeholder-[#9a9a9a] focus:border-[#4c8c39] focus:outline-none"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="flex shrink-0 flex-wrap items-center justify-end gap-x-5 gap-y-3 border-t border-[#333] bg-[#232324] px-8 py-5">
        <label
          className="flex cursor-pointer select-none items-center gap-2.5"
          onClick={() => setLaunchAfter((v) => !v)}
        >
          <span
            role="checkbox"
            aria-checked={launchAfter}
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === " " || e.key === "Enter") {
                e.preventDefault();
                setLaunchAfter((v) => !v);
              }
            }}
            className={cn(
              "flex h-[18px] w-[18px] items-center justify-center border-2 transition-colors",
              launchAfter
                ? "border-[#4c8c39] bg-[#4c8c39]"
                : "border-[#cccccc] bg-transparent hover:border-white",
            )}
          >
            {launchAfter && (
              <svg viewBox="0 0 10 8" className="h-[10px] w-[10px] fill-none stroke-white stroke-[2]">
                <path d="M1 4l2.5 2.5L9 1" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            )}
          </span>
          <span className="text-[14px] text-[#f0f0f0]">Launch after Install</span>
        </label>
        <button
          type="button"
          onClick={close}
          className="mc-btn-stone h-[36px] w-[96px] text-[14px] font-bold"
        >
          Cancel
        </button>
        <button
          type="button"
          onClick={install}
          className="mc-btn-green mc-shadow h-[36px] w-[104px] text-[14px] font-bold"
        >
          Install
        </button>
      </div>
    </div>
  );
}
