"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  Check,
  ChevronDown,
  Folder,
  MoreVertical,
  Search,
  TriangleAlert,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useLauncherStore } from "@/lib/store";
import {
  getVersion,
  iconSrc,
  launchInstallation,
  type Installation,
} from "@/lib/launcher";
import { useToast } from "@/hooks/use-toast";

type SortKey = "name" | "created" | "played";

const SORT_OPTIONS: { id: SortKey; label: string }[] = [
  { id: "name", label: "Name" },
  { id: "created", label: "Date created" },
  { id: "played", label: "Last played" },
];

/* Small custom checkbox in launcher style */
function McCheckbox({
  checked,
  label,
  onChange,
}: {
  checked: boolean;
  label: string;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer select-none items-center gap-2">
      <span
        role="checkbox"
        aria-checked={checked}
        tabIndex={0}
        onClick={() => onChange(!checked)}
        onKeyDown={(e) => {
          if (e.key === " " || e.key === "Enter") {
            e.preventDefault();
            onChange(!checked);
          }
        }}
        className={cn(
          "flex h-[16px] w-[16px] items-center justify-center border-2 transition-colors",
          checked
            ? "border-[#4c8c39] bg-[#4c8c39]"
            : "border-[#8a8886] bg-[#1c1b19] hover:border-[#9a9a9a]",
        )}
      >
        {checked && <Check className="h-3 w-3 text-white" strokeWidth={4} />}
      </span>
      <span
        className="text-[13px] text-[#e0e5e2]"
        onClick={() => onChange(!checked)}
      >
        {label}
      </span>
    </label>
  );
}

/* Row kebab menu */
function RowMenu({
  installation,
  onDelete,
  onDuplicate,
}: {
  installation: Installation;
  onDelete: () => void;
  onDuplicate: () => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        aria-label={`Options for ${installation.name}`}
        onClick={() => setOpen((o) => !o)}
        className="mc-btn-stone h-[30px] w-[34px]"
      >
        <MoreVertical className="h-4 w-4" />
      </button>
      {open && (
        <div className="absolute right-0 top-[calc(100%+4px)] z-40 w-40 border border-[#454340] bg-[#262524] py-1 shadow-[0_8px_20px_rgba(0,0,0,0.55)]">
          <button
            type="button"
            className="block w-full px-3 py-2 text-left text-[13px] text-[#e0e5e2] hover:bg-[#312f2d]"
            onClick={() => {
              onDuplicate();
              setOpen(false);
            }}
          >
            Duplicate
          </button>
          <button
            type="button"
            className="block w-full px-3 py-2 text-left text-[13px] text-[#e07a6d] hover:bg-[#312f2d]"
            onClick={() => {
              onDelete();
              setOpen(false);
            }}
          >
            Delete
          </button>
        </div>
      )}
    </div>
  );
}

export function InstallationsView() {
  const installations = useLauncherStore((s) => s.installations);
  const deleteInstallation = useLauncherStore((s) => s.deleteInstallation);
  const duplicateInstallation = useLauncherStore((s) => s.duplicateInstallation);
  const markPlayed = useLauncherStore((s) => s.markPlayed);
  const openCreateModal = useLauncherStore((s) => s.openCreateModal);
  const { toast } = useToast();

  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortKey>("name");
  const [sortOpen, setSortOpen] = useState(false);
  const [showReleases, setShowReleases] = useState(true);
  const [showSnapshots, setShowSnapshots] = useState(true);
  const [showModded, setShowModded] = useState(true);
  const sortRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!sortOpen) return;
    const onDown = (e: MouseEvent) => {
      if (sortRef.current && !sortRef.current.contains(e.target as Node))
        setSortOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [sortOpen]);

  const rows = useMemo(() => {
    let list = [...installations];
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter((i) => i.name.toLowerCase().includes(q));
    }
    if (!showReleases) list = list.filter(() => false); // all versions are releases
    list.sort((a, b) => {
      if (sort === "name") return a.name.localeCompare(b.name);
      if (sort === "created") return b.createdAt - a.createdAt;
      return (b.lastPlayed ?? 0) - (a.lastPlayed ?? 0);
    });
    return list;
  }, [installations, query, sort, showReleases]);

  const play = (inst: Installation) => {
    const v = getVersion(inst.versionId);
    launchInstallation(inst);
    markPlayed(inst.id);
    toast({
      title: `Launching ${inst.name}`,
      description: `Minecraft: Java Edition ${v.version} is starting in a new window.`,
    });
  };

  return (
    <div className="mc-scroll h-full overflow-y-auto">
      {/* Filter row */}
      <div className="border-b border-[#2a2827] px-6 pb-5 pt-5 lg:px-8">
        <div className="flex flex-wrap items-end gap-x-8 gap-y-4">
          <div>
            <label
              htmlFor="inst-search"
              className="mb-1.5 block text-[10px] font-bold uppercase tracking-[0.1em] text-[#e0e5e2]"
            >
              Search
            </label>
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#9a9a9a]" />
              <input
                id="inst-search"
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Installation name"
                className="h-[38px] w-[340px] max-w-full border-2 border-[#4c8c39] bg-[#1c1b19] pl-9 pr-3 text-[13px] text-[#e0e5e2] placeholder-[#757575] focus:border-[#5cab45] focus:outline-none"
              />
            </div>
          </div>

          <div>
            <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-[0.1em] text-[#e0e5e2]">
              Sort by
            </span>
            <div className="relative" ref={sortRef}>
              <button
                type="button"
                aria-haspopup="listbox"
                aria-expanded={sortOpen}
                onClick={() => setSortOpen((o) => !o)}
                className="flex h-[38px] w-[150px] items-center justify-between gap-2 border border-[#454340] bg-[#383733] px-3 text-[13px] text-[#e0e5e2] hover:border-[#5a5754]"
              >
                {SORT_OPTIONS.find((o) => o.id === sort)?.label}
                <ChevronDown
                  className={cn(
                    "h-4 w-4 text-[#c9c7c4] transition-transform",
                    sortOpen && "rotate-180",
                  )}
                />
              </button>
              {sortOpen && (
                <div
                  role="listbox"
                  className="absolute left-0 top-[calc(100%+4px)] z-40 w-full border border-[#454340] bg-[#262524] py-1 shadow-[0_8px_20px_rgba(0,0,0,0.55)]"
                >
                  {SORT_OPTIONS.map((o) => (
                    <button
                      key={o.id}
                      type="button"
                      role="option"
                      aria-selected={sort === o.id}
                      onClick={() => {
                        setSort(o.id);
                        setSortOpen(false);
                      }}
                      className={cn(
                        "flex w-full items-center justify-between px-3 py-2 text-left text-[13px] hover:bg-[#312f2d]",
                        sort === o.id
                          ? "font-bold text-[#e0e5e2]"
                          : "text-[#c9c7c4]",
                      )}
                    >
                      {o.label}
                      {sort === o.id && <Check className="h-4 w-4 text-[#9ec98f]" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div>
            <span className="mb-1.5 block text-[10px] font-bold uppercase tracking-[0.1em] text-[#e0e5e2]">
              Versions
            </span>
            <div className="flex h-[38px] items-center gap-5">
              <McCheckbox
                checked={showReleases}
                label="Releases"
                onChange={setShowReleases}
              />
              <McCheckbox
                checked={showSnapshots}
                label="Snapshots"
                onChange={setShowSnapshots}
              />
              <McCheckbox
                checked={showModded}
                label="Modded"
                onChange={setShowModded}
              />
            </div>
          </div>
        </div>
      </div>

      {/* New installation row */}
      <div className="border-b border-[#2a2827] px-6 py-4 lg:px-8">
        <button
          type="button"
          onClick={openCreateModal}
          className="mc-btn-stone h-[34px] w-[168px] text-[13px] font-bold"
        >
          New installation
        </button>
      </div>

      {/* Installation list */}
      <div className="px-6 lg:px-8">
        {rows.length === 0 ? (
          <div className="py-16 text-center">
            <p className="text-[14px] font-bold text-[#e0e5e2]">
              No installations found
            </p>
            <p className="mt-1 text-[12px] text-[#9a9a9a]">
              {showReleases
                ? "Try a different search, or create a new installation."
                : "Enable “Releases” in the version filter to see your installations."}
            </p>
          </div>
        ) : (
          rows.map((inst) => {
            const v = getVersion(inst.versionId);
            return (
              <div
                key={inst.id}
                className="group flex items-center gap-4 border-b border-[#2a2827] py-3 transition-colors hover:bg-[#1e1d1b]"
              >
                <div className="relative shrink-0">
                  <img
                    src={iconSrc(inst.icon)}
                    alt=""
                    className="mc-pixel h-[46px] w-[46px] object-contain"
                    draggable={false}
                  />
                  {v.old && (
                    <TriangleAlert
                      className="absolute -right-1.5 -top-1.5 h-[16px] w-[16px] fill-[#e08030] text-[#5c3210]"
                      aria-label="Older version"
                    />
                  )}
                </div>

                <div className="min-w-0 leading-tight">
                  <div className="truncate text-[15px] font-bold text-[#e0e5e2]">
                    {inst.name}
                  </div>
                  <div className="truncate text-[12px] text-[#8c8c8c]">
                    {v.version}
                  </div>
                </div>

                <div className="ml-auto flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => play(inst)}
                    className="mc-btn-green mc-shadow h-[30px] w-[74px] text-[12px] font-bold"
                  >
                    Play
                  </button>
                  <button
                    type="button"
                    aria-label={`Open game directory for ${inst.name}`}
                    title="Open game directory"
                    onClick={() =>
                      toast({
                        title: "Game directory",
                        description:
                          "The game directory opens in the launcher data folder on a desktop install.",
                      })
                    }
                    className="mc-btn-stone h-[30px] w-[34px]"
                  >
                    <Folder className="h-4 w-4" />
                  </button>
                  <RowMenu
                    installation={inst}
                    onDelete={() => {
                      deleteInstallation(inst.id);
                      toast({
                        title: "Installation deleted",
                        description: `“${inst.name}” was removed.`,
                      });
                    }}
                    onDuplicate={() => {
                      duplicateInstallation(inst.id);
                      toast({
                        title: "Installation duplicated",
                        description: `A copy of “${inst.name}” was created.`,
                      });
                    }}
                  />
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
