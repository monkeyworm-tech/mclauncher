"use client";

import { useState, useSyncExternalStore } from "react";
import { Sidebar } from "./Sidebar";
import { TopTabs } from "./TopTabs";
import { PlayView } from "./PlayView";
import { InstallationsView } from "./InstallationsView";
import { CreateInstallationModal } from "./CreateInstallationModal";
import { GameStubView, StubView } from "./StubView";
import { useLauncherStore } from "@/lib/store";
import type { GameId } from "@/lib/launcher";

const GAME_STUBS: Record<
  Exclude<GameId, "java">,
  { title: string; icon: string; subtitle: string }
> = {
  home: {
    title: "Home",
    icon: "/images/icons/home.png",
    subtitle:
      "Pick a game from the list on the left to get started. Minecraft: Java Edition is ready to play.",
  },
  bedrock: {
    title: "Minecraft: Bedrock Edition",
    icon: "/images/icons/bedrock.png",
    subtitle:
      "Bedrock Edition is not installed in this demo launcher. Java Edition is ready to play!",
  },
  dungeons2: {
    title: "Minecraft Dungeons II",
    icon: "/images/icons/dungeons2.png",
    subtitle:
      "Minecraft Dungeons II is not installed in this demo launcher. Java Edition is ready to play!",
  },
  dungeons: {
    title: "Minecraft Dungeons",
    icon: "/images/icons/dungeons.png",
    subtitle:
      "Minecraft Dungeons is not installed in this demo launcher. Java Edition is ready to play!",
  },
  legends: {
    title: "Minecraft Legends",
    icon: "/images/icons/legends.png",
    subtitle:
      "Minecraft Legends is not installed in this demo launcher. Java Edition is ready to play!",
  },
};

const emptySubscribe = () => () => {};

/** true once the app has hydrated on the client (persisted store is ready) */
function useHydrated() {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false,
  );
}

export function Launcher() {
  const mounted = useHydrated();
  const [mobileOpen, setMobileOpen] = useState(false);
  const activeTab = useLauncherStore((s) => s.activeTab);
  const activeGame = useLauncherStore((s) => s.activeGame);
  const createModalOpen = useLauncherStore((s) => s.createModalOpen);

  if (!mounted) {
    // Boot screen while the persisted state rehydrates
    return (
      <div className="flex h-screen w-full items-center justify-center bg-[#171615]">
        <span className="font-mc mc-shadow animate-pulse text-[18px] tracking-[0.08em] text-[#e0e5e2]">
          Minecraft Launcher
        </span>
      </div>
    );
  }

  const isJava = activeGame === "java";

  return (
    <div className="flex h-screen w-full overflow-hidden bg-[#171615]">
      <Sidebar
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        {isJava ? (
          <TopTabs onOpenMobileMenu={() => setMobileOpen(true)} />
        ) : (
          <header className="flex shrink-0 items-center border-b border-[#2a2827] bg-[#201f1d] px-6 py-4 lg:px-8">
            <button
              type="button"
              className="mr-3 rounded p-1 text-[#bbb4b1] hover:bg-[#2a2827] hover:text-white lg:hidden"
              onClick={() => setMobileOpen(true)}
              aria-label="Open menu"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current stroke-2">
                <path d="M4 6h16M4 12h16M4 18h16" strokeLinecap="round" />
              </svg>
            </button>
            <span className="text-[11px] font-bold uppercase tracking-[0.1em] text-[#d8dbd7]">
              {GAME_STUBS[activeGame as Exclude<GameId, "java">].title}
            </span>
          </header>
        )}

        <main className="mc-scroll min-h-0 flex-1 overflow-y-auto">
          {isJava ? (
            activeTab === "play" ? (
              <PlayView />
            ) : activeTab === "installations" ? (
              <InstallationsView />
            ) : (
              <StubView variant={activeTab} />
            )
          ) : (
            <GameStubView {...GAME_STUBS[activeGame as Exclude<GameId, "java">]} />
          )}
        </main>
      </div>

      {createModalOpen && <CreateInstallationModal />}
    </div>
  );
}
