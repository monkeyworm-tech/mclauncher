"use client";

import { useEffect, useRef, useState } from "react";
import {
  Check,
  ChevronDown,
  ChevronRight,
  Copy,
  Gift,
  Layers,
  MoreVertical,
  MousePointer2,
  Plus,
  TriangleAlert,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useLauncherStore } from "@/lib/store";
import {
  getVersion,
  iconSrc,
  launchInstallation,
} from "@/lib/launcher";
import { useToast } from "@/hooks/use-toast";

/* ------------------------------------------------------------------ */
/* Version selector dropdown (lists installations)                     */
/* ------------------------------------------------------------------ */
function VersionDropdown() {
  const installations = useLauncherStore((s) => s.installations);
  const selectedId = useLauncherStore((s) => s.selectedId);
  const select = useLauncherStore((s) => s.select);
  const setTab = useLauncherStore((s) => s.setTab);
  const openCreateModal = useLauncherStore((s) => s.openCreateModal);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const selected =
    installations.find((i) => i.id === selectedId) ?? installations[0];

  if (!selected) {
    return (
      <button
        type="button"
        onClick={() => {
          setTab("installations");
          openCreateModal();
        }}
        className="mc-btn-stone h-[52px] w-[320px] text-[13px] font-bold"
      >
        <Plus className="h-4 w-4" /> New installation
      </button>
    );
  }

  const selectedVersion = getVersion(selected.versionId);

  return (
    <div className="relative w-[396px] max-w-full shrink-0" ref={ref}>
      <button
        type="button"
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "flex h-[56px] w-full items-center gap-3 px-3 text-left transition-colors",
          "border-2 bg-[#383733]",
          open
            ? "border-[#4c8c39]"
            : "border-[#454340] hover:border-[#5a5754]",
        )}
      >
        <img
          src={iconSrc(selected.icon)}
          alt=""
          className="mc-pixel h-[42px] w-[42px] shrink-0 object-contain"
          draggable={false}
        />
        <span className="min-w-0 flex-1 leading-tight">
          <span className="block truncate text-[15px] font-bold text-[#daded7]">
            {selected.name}
          </span>
          <span className="block truncate text-[11px] text-[#a8a8a6]">
            {selectedVersion.version}
          </span>
        </span>
        <ChevronDown
          className={cn(
            "h-5 w-5 shrink-0 text-[#c9c7c4] transition-transform",
            open && "rotate-180",
          )}
        />
      </button>

      {open && (
        <div
          role="listbox"
          className="mc-scroll absolute left-0 right-0 top-[calc(100%+4px)] z-50 max-h-[300px] overflow-y-auto border-2 border-[#454340] bg-[#262524] shadow-[0_10px_24px_rgba(0,0,0,0.55)]"
        >
          {installations.map((inst) => {
            const v = getVersion(inst.versionId);
            const isSel = inst.id === selected.id;
            return (
              <button
                key={inst.id}
                type="button"
                role="option"
                aria-selected={isSel}
                onClick={() => {
                  select(inst.id);
                  setOpen(false);
                }}
                className={cn(
                  "flex w-full items-center gap-3 px-3 py-2.5 text-left transition-colors",
                  isSel
                    ? "bg-[#4a4846] ring-1 ring-inset ring-[#8a8886]"
                    : "hover:bg-[#312f2d]",
                )}
              >
                <span className="relative shrink-0">
                  <img
                    src={iconSrc(inst.icon)}
                    alt=""
                    className="mc-pixel h-[34px] w-[34px] object-contain"
                    draggable={false}
                  />
                  {v.old && (
                    <TriangleAlert
                      className="absolute -right-1.5 -top-1.5 h-[15px] w-[15px] fill-[#e08030] text-[#5c3210]"
                      aria-label="Older version"
                    />
                  )}
                </span>
                <span className="min-w-0 flex-1 leading-tight">
                  <span className="block truncate text-[13px] font-bold text-[#daded7]">
                    {inst.name}
                  </span>
                  <span className="block truncate text-[11px] text-[#a8a8a6]">
                    {v.version}
                  </span>
                </span>
                {isSel && <Check className="h-4 w-4 shrink-0 text-[#9ec98f]" />}
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => {
              setOpen(false);
              setTab("installations");
              openCreateModal();
            }}
            className="flex w-full items-center justify-center gap-2 border-t border-[#3a3836] py-2.5 text-[12px] font-bold text-[#9ec98f] transition-colors hover:bg-[#312f2d]"
          >
            <Plus className="h-4 w-4" /> New installation
          </button>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* News cards                                                          */
/* ------------------------------------------------------------------ */
const NEWS = [
  {
    img: "/images/cards/news-1.png",
    title: "Dark spires rise in Dungeons II",
    desc: "Storm the floating fortresses in the newest Dungeons II adventure.",
  },
  {
    img: "/images/cards/news-2.png",
    title: "Builder's Update is here",
    desc: "Hard hats on — scaffolding, cranes and new construction blocks.",
  },
  {
    img: "/images/cards/news-3.png",
    title: "Deep dive: the Crimson Grove",
    desc: "A glowing new biome — and the shadowy mobs that call it home.",
  },
];

function NewsCards() {
  return (
    <section
      className="grid shrink-0 grid-cols-1 gap-5 px-6 pb-6 sm:grid-cols-2 lg:grid-cols-3 lg:px-8"
      aria-label="Latest news"
    >
      {NEWS.map((n) => (
        <article
          key={n.title}
          className="group cursor-pointer border border-[#2a2827] bg-[#201f1d] transition-colors hover:border-[#454340]"
        >
          <div className="h-[120px] overflow-hidden">
            <img
              src={n.img}
              alt={n.title}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
            />
          </div>
          <div className="px-4 py-2.5">
            <h3 className="text-[13px] font-bold leading-snug text-[#e0e5e2]">
              {n.title}
            </h3>
            <p className="mt-1 text-[11px] leading-snug text-[#9a9a9a]">
              {n.desc}
            </p>
          </div>
        </article>
      ))}
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Play page                                                           */
/* ------------------------------------------------------------------ */
export function PlayView() {
  const installations = useLauncherStore((s) => s.installations);
  const selectedId = useLauncherStore((s) => s.selectedId);
  const markPlayed = useLauncherStore((s) => s.markPlayed);
  const setTab = useLauncherStore((s) => s.setTab);
  const { toast } = useToast();
  const [showGift, setShowGift] = useState(true);

  const selected =
    installations.find((i) => i.id === selectedId) ?? installations[0];

  const play = () => {
    if (!selected) return;
    const v = getVersion(selected.versionId);
    launchInstallation(selected);
    markPlayed(selected.id);
    toast({
      title: `Launching ${selected.name}`,
      description: `Minecraft: Java Edition ${v.version} is starting in a new window.`,
    });
  };

  return (
    <div className="flex min-h-full flex-col">
      {/* Banner */}
      <section className="relative min-h-[300px] flex-1 overflow-hidden">
        <img
          src="/images/banner.png"
          alt="Minecraft: Java Edition key art"
          className="absolute inset-0 h-full w-full object-cover object-[center_28%]"
          draggable={false}
        />
        <div
          aria-hidden
          className="absolute inset-0 bg-gradient-to-b from-[#171615]/5 via-transparent to-[#171615]/90"
        />

        {/* Minecraft logo */}
        <img
          src="/images/logo.png"
          alt="Minecraft: Java Edition"
          className="absolute left-1/2 top-[17%] w-[min(360px,46%)] -translate-x-1/2 drop-shadow-[0_6px_16px_rgba(0,0,0,0.6)] xl:top-[7%] xl:w-[min(400px,52%)]"
          draggable={false}
        />

        {/* Realm promo: full-width bar on small screens, side panel on wide ones */}
        <button
          type="button"
          onClick={() => setTab("realms")}
          className={cn(
            "absolute flex items-center bg-[#272625]/95 text-left transition-colors hover:bg-[#2e2c2a]",
            "inset-x-0 top-0 w-full justify-between px-4 py-2.5",
            "xl:inset-x-auto xl:bottom-auto xl:right-0 xl:w-auto xl:max-w-[360px] xl:justify-start xl:gap-4 xl:px-7 xl:py-6",
          )}
        >
          <span className="font-mc mc-shadow text-[11px] leading-[1.6] text-white xl:text-[15px]">
            Try your own Realm for free!
          </span>
          <ChevronRight className="h-4 w-4 shrink-0 text-white xl:h-5 xl:w-5" />
        </button>

        {/* Bottom-left corner button (cursor promo, like the launcher) */}
        <button
          type="button"
          aria-label="Custom cursor promo"
          title="Custom cursor"
          onClick={() =>
            toast({
              title: "Custom cursors",
              description: "Grab the new Minecraft cursor pack in the full launcher.",
            })
          }
          className="absolute bottom-4 left-4 flex h-[52px] w-[52px] items-center justify-center border border-black/40 bg-[#262524]/90 text-[#c9c7c4] transition-colors hover:text-white"
        >
          <MousePointer2 className="h-6 w-6" />
        </button>

        {/* Gift promo */}
        {showGift && (
          <div className="absolute bottom-3 right-3 flex max-w-[calc(100%-24px)] flex-wrap items-stretch justify-end gap-2">
            <div className="relative max-w-[320px] border-2 border-black bg-[#55b04a] pl-4 pr-7 shadow-[0_4px_12px_rgba(0,0,0,0.4)]">
              <p className="font-mc mc-shadow-dark text-[12px] leading-[1.5] text-[#12240b]">
                Give the gift of Minecraft and play together with your friends!
              </p>
              <button
                type="button"
                onClick={() => setShowGift(false)}
                aria-label="Dismiss gift promo"
                className="absolute right-1 top-1 p-0.5 text-[#12240b]/70 transition-colors hover:text-[#12240b]"
              >
                <X className="h-3.5 w-3.5" strokeWidth={3} />
              </button>
            </div>
            <button
              type="button"
              onClick={() =>
                toast({
                  title: "Minecraft as a gift",
                  description:
                    "Give the gift of Minecraft and play together with your friends!",
                })
              }
              className="flex items-center gap-2.5 border-2 border-black/70 bg-[#3c3c3c] px-5 py-3 text-[14px] font-bold text-white transition-colors hover:bg-[#464646]"
            >
              <Gift className="h-5 w-5 text-[#e88ba6]" />
              Buy as Gift
            </button>
          </div>
        )}
      </section>

      {/* Play row */}
      <div className="flex shrink-0 flex-wrap items-center gap-4 bg-[#171615] px-6 py-4 lg:gap-5 lg:px-8">
        <VersionDropdown />

        <button
          type="button"
          onClick={play}
          disabled={!selected}
          className="mc-btn-green mc-shadow h-[64px] w-[292px] font-mc text-[24px] tracking-[0.06em]"
        >
          PLAY
        </button>

        <div className="hidden items-center gap-1 sm:flex">
          <button
            type="button"
            aria-label="Installation quick actions"
            title="Quick actions"
            onClick={() =>
              toast({
                title: "Installations",
                description: "Manage your installations in the Installations tab.",
              })
            }
            className="flex h-[42px] w-[42px] items-center justify-center border border-[#383733] bg-[#262524] text-[#bbb4b1] transition-colors hover:border-[#5a5754] hover:text-white"
          >
            <Layers className="h-5 w-5" />
          </button>
          <button
            type="button"
            aria-label="More play options"
            title="More options"
            onClick={() =>
              toast({
                title: "Launcher options",
                description: "v.3.43.21-2.6.2 — everything is up to date.",
              })
            }
            className="flex h-[42px] w-[42px] items-center justify-center border border-[#383733] bg-[#262524] text-[#bbb4b1] transition-colors hover:border-[#5a5754] hover:text-white"
          >
            <MoreVertical className="h-5 w-5" />
          </button>
        </div>

        <div className="ml-auto flex items-center gap-2">
          <span className="text-[13px] text-[#c9c7c4]">CoolGamePat</span>
          <button
            type="button"
            aria-label="Copy player name"
            title="Copy player name"
            onClick={() => {
              navigator.clipboard
                ?.writeText("CoolGamePat")
                .catch(() => undefined);
              toast({ title: "Player name copied", description: "CoolGamePat" });
            }}
            className="p-1.5 text-[#bbb4b1] transition-colors hover:text-white"
          >
            <Copy className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* News cards */}
      <NewsCards />
    </div>
  );
}
