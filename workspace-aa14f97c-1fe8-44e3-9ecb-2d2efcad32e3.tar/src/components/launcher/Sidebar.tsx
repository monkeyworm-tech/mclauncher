"use client";

import { ChevronDown, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useLauncherStore } from "@/lib/store";
import type { GameId } from "@/lib/launcher";

interface NavItem {
  id: GameId | "whatsnew" | "settings";
  icon: string;
  lines: string[];
}

const NAV_ITEMS: NavItem[] = [
  { id: "home", icon: "/images/icons/home.png", lines: ["HOME"] },
  {
    id: "java",
    icon: "/images/icons/java.png",
    lines: ["MINECRAFT:", "JAVA EDITION"],
  },
  {
    id: "bedrock",
    icon: "/images/icons/bedrock.png",
    lines: ["MINECRAFT:", "BEDROCK EDITION"],
  },
  {
    id: "dungeons2",
    icon: "/images/icons/dungeons2.png",
    lines: ["MINECRAFT", "DUNGEONS II"],
  },
  {
    id: "dungeons",
    icon: "/images/icons/dungeons.png",
    lines: ["MINECRAFT", "DUNGEONS"],
  },
  {
    id: "legends",
    icon: "/images/icons/legends.png",
    lines: ["MINECRAFT", "LEGENDS"],
  },
];

function SidebarButton({
  item,
  active,
  onClick,
}: {
  item: NavItem;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={cn(
        "relative flex w-full items-center gap-3 border-b border-[#262422] px-4 py-[15px] text-left transition-colors",
        active
          ? "bg-[#4e4c49]"
          : "bg-[#3d3a37] hover:bg-[#46433f] active:bg-[#4e4c49]",
      )}
    >
      {active && (
        <span
          aria-hidden
          className="absolute bottom-0 left-0 top-0 w-1 bg-[#ecebeb]"
        />
      )}
      <span className="relative shrink-0">
        <img
          src={item.icon}
          alt=""
          className="mc-pixel h-7 w-7 object-contain"
          draggable={false}
        />
      </span>
      <span className="min-w-0 text-[12px] font-bold uppercase leading-[1.3] tracking-[0.02em] text-[#e0e5e2]">
        {item.lines.map((l, i) => (
          <span key={i} className="block truncate">
            {l}
          </span>
        ))}
      </span>
    </button>
  );
}

export function Sidebar({
  mobileOpen,
  onCloseMobile,
}: {
  mobileOpen: boolean;
  onCloseMobile: () => void;
}) {
  const activeGame = useLauncherStore((s) => s.activeGame);
  const setGame = useLauncherStore((s) => s.setGame);
  const setTab = useLauncherStore((s) => s.setTab);

  return (
    <>
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 lg:hidden"
          onClick={onCloseMobile}
          aria-hidden
        />
      )}
      <aside
        className={cn(
          "z-50 flex w-[216px] shrink-0 flex-col border-r border-[#262422] bg-[#312d2c]",
          "max-lg:fixed max-lg:inset-y-0 max-lg:left-0 max-lg:transition-transform",
          mobileOpen ? "max-lg:translate-x-0" : "max-lg:-translate-x-full",
        )}
        aria-label="Launcher navigation"
      >
        {/* Account header */}
        <button
          type="button"
          className="relative flex h-[76px] w-full items-center gap-3 border-b border-[#262422] bg-[#3a3734] px-4 text-left hover:bg-[#443f3b]"
        >
          <img
            src="/images/icons/avatar.png"
            alt="Account avatar"
            className="mc-pixel h-[34px] w-[34px] rounded-[3px] object-contain"
          />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[14px] font-bold leading-tight text-[#e0e5e2]">
              CoolGame Pat
            </span>
            <span className="block truncate text-[11px] leading-tight text-[#9a9a9a]">
              Microsoft account
            </span>
          </span>
          <ChevronDown className="h-4 w-4 shrink-0 text-[#bbb4b1]" />
        </button>

        {/* Game list */}
        <nav className="mc-scroll flex-1 overflow-y-auto">
          {NAV_ITEMS.map((item) => (
            <SidebarButton
              key={item.id}
              item={item}
              active={activeGame === item.id}
              onClick={() => {
                setGame(item.id as GameId);
                onCloseMobile();
              }}
            />
          ))}
        </nav>

        {/* Bottom section */}
        <div className="border-t border-[#262422]">
          <SidebarButton
            item={{
              id: "whatsnew",
              icon: "/images/icons/whatsnew.png",
              lines: ["WHAT'S NEW"],
            }}
            active={false}
            onClick={() => {
              setGame("java");
              setTab("patch-notes");
              onCloseMobile();
            }}
          />
          <SidebarButton
            item={{
              id: "settings",
              icon: "/images/icons/settings.png",
              lines: ["SETTINGS"],
            }}
            active={false}
            onClick={() => {
              setGame("java");
              setTab("patch-notes");
              onCloseMobile();
            }}
          />
          <div className="px-4 pb-3 pt-1 text-[10px] text-[#8c8987]">
            v.3.43.21-2.6.2
          </div>
        </div>

        <button
          type="button"
          className="absolute right-3 top-3 text-[#bbb4b1] hover:text-white lg:hidden"
          onClick={onCloseMobile}
          aria-label="Close menu"
        >
          <X className="h-5 w-5" />
        </button>
      </aside>
    </>
  );
}
