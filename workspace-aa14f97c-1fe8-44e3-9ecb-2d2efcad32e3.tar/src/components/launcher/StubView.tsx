"use client";

import { Gift, Globe, ScrollText, Shirt } from "lucide-react";

const STUB_CONTENT: Record<string, { icon: React.ReactNode; title: string; message: string }> = {
  realms: {
    icon: <Globe className="h-10 w-10" />,
    title: "Realms",
    message: "Try your own Realm for free! Realms are not part of this demo launcher yet.",
  },
  skins: {
    icon: <Shirt className="h-10 w-10" />,
    title: "Skins",
    message: "Manage your skins here in the full launcher.",
  },
  "patch-notes": {
    icon: <ScrollText className="h-10 w-10" />,
    title: "Patch Notes",
    message: "Read all about the latest Minecraft: Java Edition updates.",
  },
  gift: {
    icon: <Gift className="h-10 w-10" />,
    title: "Give the gift of Minecraft",
    message: "Play together with your friends!",
  },
};

export function StubView({ variant }: { variant: string }) {
  const c = STUB_CONTENT[variant] ?? {
    icon: <Globe className="h-10 w-10" />,
    title: variant,
    message: "This page is not part of the demo launcher yet.",
  };
  return (
    <div className="flex h-full flex-col items-center justify-center gap-4 px-6 text-center">
      <div className="flex h-16 w-16 items-center justify-center border border-[#2a2827] bg-[#201f1d] text-[#9ec98f]">
        {c.icon}
      </div>
      <h2 className="text-[20px] font-bold text-[#e0e5e2]">{c.title}</h2>
      <p className="max-w-[420px] text-[13px] leading-relaxed text-[#9a9a9a]">
        {c.message}
      </p>
    </div>
  );
}

/* Stub page for the other games in the sidebar (Bedrock, Dungeons, ...) */
export function GameStubView({
  title,
  icon,
  subtitle,
}: {
  title: string;
  icon: string;
  subtitle: string;
}) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-5 px-6 text-center">
      <img
        src={icon}
        alt=""
        className="mc-pixel h-20 w-20 object-contain"
        draggable={false}
      />
      <div>
        <h2 className="text-[22px] font-bold text-[#e0e5e2]">{title}</h2>
        <p className="mt-2 max-w-[440px] text-[13px] leading-relaxed text-[#9a9a9a]">
          {subtitle}
        </p>
      </div>
      <button
        type="button"
        className="mc-btn-stone h-[34px] px-5 text-[13px] font-bold"
        onClick={() => window.open("https://www.minecraft.net", "_blank")}
      >
        Get it on minecraft.net
      </button>
    </div>
  );
}
