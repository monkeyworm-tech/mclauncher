"use client";

import { Menu } from "lucide-react";
import { cn } from "@/lib/utils";
import { useLauncherStore } from "@/lib/store";
import type { TabId } from "@/lib/launcher";

const TABS: { id: TabId; label: string; dot?: boolean }[] = [
  { id: "play", label: "Play" },
  { id: "installations", label: "Installations" },
  { id: "realms", label: "Realms", dot: true },
  { id: "skins", label: "Skins" },
  { id: "patch-notes", label: "Patch Notes" },
];

export function TopTabs({ onOpenMobileMenu }: { onOpenMobileMenu: () => void }) {
  const activeTab = useLauncherStore((s) => s.activeTab);
  const setTab = useLauncherStore((s) => s.setTab);

  return (
    <header className="shrink-0 border-b border-[#2a2827] bg-[#201f1d]">
      <div className="flex items-center gap-3 px-6 pt-3 lg:px-8">
        <button
          type="button"
          className="rounded p-1 text-[#bbb4b1] hover:bg-[#2a2827] hover:text-white lg:hidden"
          onClick={onOpenMobileMenu}
          aria-label="Open menu"
        >
          <Menu className="h-5 w-5" />
        </button>
        <span className="text-[12px] font-bold uppercase tracking-[0.1em] text-[#d8dbd7]">
          Minecraft: Java Edition
        </span>
      </div>
      <nav
        className="mc-scroll mt-1 flex items-center gap-4 overflow-x-auto whitespace-nowrap px-4 sm:gap-7 sm:px-6 lg:px-8"
        aria-label="Game tabs"
      >
        {TABS.map((tab) => {
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setTab(tab.id)}
              aria-current={active ? "page" : undefined}
              className={cn(
                "relative shrink-0 pb-[11px] pt-1 text-[13px] transition-colors sm:text-[17px]",
                active
                  ? "font-bold text-[#e0e5e2]"
                  : "font-normal text-[#bbb4b1] hover:text-[#e0e5e2]",
              )}
            >
              <span className="relative">
                {tab.label}
                {tab.dot && (
                  <span
                    aria-hidden
                    className="absolute -right-2 -top-1 h-[6px] w-[6px] rounded-full bg-[#55b04a]"
                  />
                )}
              </span>
              {active && (
                <span
                  aria-hidden
                  className="absolute inset-x-0 bottom-0 h-[3px] bg-[#3c8527]"
                />
              )}
            </button>
          );
        })}
      </nav>
    </header>
  );
}
