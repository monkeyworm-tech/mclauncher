/* Minecraft Launcher — data model and version catalog */

export type VersionId = "latest-release" | "release-26-2" | "release-1-20-6";

export interface GameVersion {
  id: VersionId;
  /** Label shown in the VERSION dropdown of the create-installation dialog */
  label: string;
  /** Short version string shown as faded subtext */
  version: string;
  /** HTML file launched in a new window when playing this version */
  html: string;
  /** Older versions show a warning badge */
  old?: boolean;
}

export const VERSIONS: GameVersion[] = [
  {
    id: "latest-release",
    label: "Latest release (26.3)",
    version: "26.3",
    html: "26-3.html",
  },
  {
    id: "release-26-2",
    label: "release 26.2",
    version: "26.2",
    html: "26-2.html",
  },
  {
    id: "release-1-20-6",
    label: "release 1.20.6",
    version: "1.20.6",
    html: "20-6.html",
    old: true,
  },
];

export function getVersion(id: VersionId): GameVersion {
  return VERSIONS.find((v) => v.id === id) ?? VERSIONS[0];
}

export type InstallIcon = "grass" | "furnace" | "crafting";

export const INSTALL_ICONS: { id: InstallIcon; label: string; src: string }[] = [
  { id: "furnace", label: "Furnace", src: "/images/furnace.png" },
  { id: "grass", label: "Grass Block", src: "/images/icons/grass.png" },
  { id: "crafting", label: "Crafting Table", src: "/images/crafting-table.png" },
];

export function iconSrc(icon: InstallIcon): string {
  return INSTALL_ICONS.find((i) => i.id === icon)?.src ?? INSTALL_ICONS[0].src;
}

export interface Installation {
  id: string;
  name: string;
  versionId: VersionId;
  icon: InstallIcon;
  directory?: string;
  resolutionW?: string;
  resolutionH?: string;
  createdAt: number;
  lastPlayed?: number;
}

/** Installations that ship with the launcher */
export function defaultInstallations(): Installation[] {
  return [
    {
      id: "inst-latest-release",
      name: "Latest release",
      versionId: "latest-release",
      icon: "grass",
      createdAt: 1735689600000,
      lastPlayed: 1762521600000,
    },
    {
      id: "inst-release-26-2",
      name: "release 26.2",
      versionId: "release-26-2",
      icon: "furnace",
      createdAt: 1732924800000,
    },
    {
      id: "inst-release-1-20-6",
      name: "release 1.20.6",
      versionId: "release-1-20-6",
      icon: "crafting",
      createdAt: 1717459200000,
    },
  ];
}

export type TabId = "play" | "installations" | "realms" | "skins" | "patch-notes";

export type GameId =
  | "home"
  | "java"
  | "bedrock"
  | "dungeons2"
  | "dungeons"
  | "legends";

/** Open the game HTML file for an installation in a new window */
export function launchInstallation(inst: Installation): Window | null {
  const v = getVersion(inst.versionId);
  const w = parseInt(inst.resolutionW ?? "", 10);
  const h = parseInt(inst.resolutionH ?? "", 10);
  const width = Number.isFinite(w) && w > 0 ? w : 1280;
  const height = Number.isFinite(h) && h > 0 ? h : 760;
  let win: Window | null = null;
  try {
    win = window.open(`/${v.html}`, "_blank", `width=${width},height=${height}`);
  } catch {
    win = null;
  }
  if (!win) {
    win = window.open(`/${v.html}`, "_blank");
  }
  return win;
}
