"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import {
  defaultInstallations,
  type Installation,
  type TabId,
  type GameId,
} from "./launcher";

interface LauncherState {
  installations: Installation[];
  selectedId: string;
  activeTab: TabId;
  activeGame: GameId;
  createModalOpen: boolean;
  openCreateModal: () => void;
  closeCreateModal: () => void;
  addInstallation: (inst: Installation) => void;
  deleteInstallation: (id: string) => void;
  duplicateInstallation: (id: string) => void;
  select: (id: string) => void;
  setTab: (tab: TabId) => void;
  setGame: (game: GameId) => void;
  markPlayed: (id: string) => void;
}

export const useLauncherStore = create<LauncherState>()(
  persist(
    (set, get) => ({
      installations: defaultInstallations(),
      selectedId: "inst-latest-release",
      activeTab: "play",
      activeGame: "java",
      createModalOpen: false,
      openCreateModal: () => set({ createModalOpen: true }),
      closeCreateModal: () => set({ createModalOpen: false }),
      addInstallation: (inst) =>
        set((s) => ({
          installations: [...s.installations, inst],
          selectedId: inst.id,
        })),
      deleteInstallation: (id) =>
        set((s) => {
          const installations = s.installations.filter((i) => i.id !== id);
          const selectedId =
            s.selectedId === id
              ? (installations[0]?.id ?? "")
              : s.selectedId;
          return { installations, selectedId };
        }),
      duplicateInstallation: (id) => {
        const src = get().installations.find((i) => i.id === id);
        if (!src) return;
        set((s) => ({
          installations: [
            ...s.installations,
            {
              ...src,
              id: `inst-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
              name: `${src.name} copy`,
              createdAt: Date.now(),
              lastPlayed: undefined,
            },
          ],
        }));
      },
      select: (id) => set({ selectedId: id }),
      setTab: (tab) => set({ activeTab: tab }),
      setGame: (game) =>
        set({
          activeGame: game,
          activeTab: game === "java" ? get().activeTab : "play",
        }),
      markPlayed: (id) =>
        set((s) => ({
          installations: s.installations.map((i) =>
            i.id === id ? { ...i, lastPlayed: Date.now() } : i,
          ),
        })),
    }),
    {
      name: "minecraft-launcher-state",
      storage: createJSONStorage(() => localStorage),
    },
  ),
);
